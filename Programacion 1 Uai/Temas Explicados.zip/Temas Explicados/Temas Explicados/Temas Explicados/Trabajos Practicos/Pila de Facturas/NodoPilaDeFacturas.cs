﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados.Trabajos_Practicos.Pila_de_Facturas
{
    public class NodoPilaDeFacturas
    {
        public int NumeroDeFactura {  get; set; }
        public int NumeroDeCliente { get; set; }
        public float Importe { get; set; }
        public DateTime Fecha { get; set; }
        public NodoPilaDeFacturas Siguiente { get; set; }

        public NodoPilaDeFacturas(int numerodefactura,int numerodecliente,float importe, DateTime fecha)
        {
            this.NumeroDeFactura = numerodefactura;
            this.NumeroDeCliente = numerodecliente;
            this.Importe = importe;
            this.Fecha = fecha;
            this.Siguiente = null;
        }
    }
}
