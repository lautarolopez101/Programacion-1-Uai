﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Temas_Explicados.Teorias.Lista_Doblemente_Enlazada;
using Temas_Explicados.Teorias.Manejo_de_Archivo;
using Temas_Explicados.Teorias.Manejo_de_Varios_Archivos;
using Temas_Explicados.Trabajos_Practicos.Pila_de_Facturas;

namespace Temas_Explicados
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregarLista_Click(object sender, EventArgs e)
        {

        }
        private void listaEnlazadaSimpleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                Lista_Simple_Enlazada lista = new Lista_Simple_Enlazada();
                lista.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pilasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FRMPilas pila = new FRMPilas();
                pila.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void colasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FRMColas cola = new FRMColas();
                cola.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void blocDeNotasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                _5FRMBloc_de_Notas notas = new _5FRMBloc_de_Notas();
                notas.Show();   
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void paintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FRMPaint paint = new FRMPaint();
                paint.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listaEnlazadaDeEqToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                EquiposElectronicos equipo = new EquiposElectronicos();
                equipo.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pilaDeFacturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FRMPilaDeFacturas piladefacturas = new FRMPilaDeFacturas();
                piladefacturas.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void colaDeSolicitudesDeEmpleoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listaDoblementeEnlazadaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
                lista.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void manejoDeArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoArchivo archivo = new ManejoArchivo();
                archivo.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void manejoDeVariosArchivosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                 ManejoVariosArchivos archivos = new ManejoVariosArchivos();
                archivos.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
