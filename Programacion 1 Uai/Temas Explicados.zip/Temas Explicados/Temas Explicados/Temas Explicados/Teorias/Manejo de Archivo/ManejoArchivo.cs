﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados.Teorias.Manejo_de_Archivo
{
    public partial class ManejoArchivo : Form
    {
        public ManejoArchivo()
        {
            InitializeComponent();
        }

        // Lista interna para manejar los datos
        private List<string[]> datos = new List<string[]>();

        private void ManejoArchivo_Load(object sender, EventArgs e)
        {
            CargarDatos();
        }

        private void CargarDatos()
        {
            datos.Clear(); // Limpiar la lista de datos
            dataGridView1.Rows.Clear(); // Limpiar el DataGridView

            if (File.Exists("Archivo.txt"))
            {
                using (StreamReader sr = new StreamReader("Archivo.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector); // Mostrar en el DataGridView
                    }
                }
            }
        }

        private void GuardarDatos()
        {
            // Ordenar los datos por categoría y subcategoría
            datos = datos.OrderBy(d => d[0]).ThenBy(d => d[1]).ToList();

            using (StreamWriter sw = new StreamWriter("Archivo.txt"))
            {
                foreach(var vector in datos)
                {
                    sw.WriteLine(string.Join(";", vector)); // Escribir en el archivo
                }
            }
        }

        private void AgregarDatos(string categoria, string subcategoria, string producto, string precio)
        {
            // Crear un nuevo dato y agregarlo a la lista y al DataGridView
            string[] nuevoDato = { categoria, subcategoria, producto, precio };
            datos.Add(nuevoDato);
            dataGridView1.Rows.Add(nuevoDato);

            // Guardar datos actualizados
            GuardarDatos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Capturar los valores de las cajas de texto
            string categoria = txtCategoria.Text;
            string subcategoria = txtSubcategoria.Text;
            string producto = txtProducto.Text;
            string precio = txtPrecio.Text;

            // Validar que todos los campos estén completos
            if (string.IsNullOrWhiteSpace(categoria) ||
                string.IsNullOrWhiteSpace(subcategoria) ||
                string.IsNullOrWhiteSpace(producto) ||
                string.IsNullOrWhiteSpace(precio))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            // Agregar los datos
            AgregarDatos(categoria, subcategoria, producto, precio);

            // Limpiar los campos para la próxima entrada
            txtCategoria.Clear();
            txtSubcategoria.Clear();
            txtProducto.Clear();
            txtPrecio.Clear();

            MessageBox.Show("Datos agregados correctamente.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text += "Reporte" + Environment.NewLine;
            FileStream fs = new FileStream("Archivo.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            string Linea = "";
            string[] vector = new string[0];
            string categoria = "";
            string subcategoria = "";
            sr.ReadLine();
            Linea = sr.ReadLine();
            while (Linea != null)
            {
                vector = Linea.Split(';');
                if (vector[0] != categoria)
                {
                    textBox1.Text += "========================================"+ Environment.NewLine;
                    textBox1.Text += "Categoria: ";
                    textBox1.Text += vector[0] + Environment.NewLine;
                   
                    categoria = vector[0];
                }
                if (vector[1] != subcategoria)
                {
                    textBox1.Text += "========================================" + Environment.NewLine;
                    textBox1.Text += "SubCategoria: ";
                    textBox1.Text += vector[1] + Environment.NewLine;
                    subcategoria = vector[1];
                    textBox1.Text += "----------------------------------------" + Environment.NewLine;
                    textBox1.Text += "Producto " + "Precio " + Environment.NewLine;
                    textBox1.Text += "----------------------------------------" + Environment.NewLine;

                }
                textBox1.Text += vector[2] + "\t" + vector[3] + Environment.NewLine;
                Linea = sr.ReadLine();

            }
            sr.Close();
            fs.Close();

        }
    }
}
