﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.VisualStyles;

namespace Temas_Explicados.Teorias.Manejo_de_Varios_Archivos
{
    public partial class Productos : Form
    {
        public Productos()
        {
            InitializeComponent();
        }
        private List<string[]> datos = new List<string[]>();

        private void Cargodatos()
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Productos.csv"))
            {
                using (StreamReader sr = new StreamReader("Productos.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }
        private void Productos_Load(object sender, EventArgs e)
        {
            Cargodatos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string id = txtIdProducto.Text;
            string producto= txtNombreProducto.Text;
            string precio = txtPrecio.Text;

            if (string.IsNullOrEmpty(id) ||
                string.IsNullOrEmpty(producto) ||
                string.IsNullOrEmpty(precio))
            {
                MessageBox.Show("Por favor, completa todos los campos");
                return;
            }
            AgregarDatos(id,producto,precio);
            txtIdProducto.Clear();
            txtNombreProducto.Clear();
            txtPrecio.Clear();
            txtIdProducto.Focus();
            MessageBox.Show("Datos guardados Correctamente.");
        }

        private void AgregarDatos(string id, string producto,string precio)
        {
            string[] nuevodato = { id,producto,precio};
            datos.Add(nuevodato);
            dataGridView1.Rows.Add(nuevodato);
            GuardarDatos();
        }

        private void GuardarDatos()
        {
            datos = datos.OrderBy(d => d[0]).ThenBy(d => d[1]).ToList();
            using (StreamWriter sw = new StreamWriter("Productos.csv"))
            {
                foreach (var vector in datos)
                {
                    sw.WriteLine(string.Join(";", vector));
                }
            }
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Productos.csv"))
            {
                using (StreamReader sr = new StreamReader("Productos.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }
    }
}
