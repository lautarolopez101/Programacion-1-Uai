﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados
{
    public partial class FRMColas : Form
    {
        private int poc;
        Cola _cola = new Cola();
        public FRMColas()
        {
            InitializeComponent();
        }

        

        private void btnEncolar_Click(object sender, EventArgs e)
        {
            if(txtNombre.Text.Length > 0 )
            {
                NodoCola unNuevoNodo = new NodoCola();
                unNuevoNodo.Nombre = txtNombre.Text;
                _cola.Encolar(unNuevoNodo);
                txtNombre.Clear();
                txtNombre.Focus();
                MostrarCola();
            }
            else
            {
                MessageBox.Show("No Ingresaste Ningun Nombre");
            }
        }
         
        private void MostrarCola()
        {
            LstCola.Items.Clear();
            MostrarNodoEnPantalla(_cola.Inicio);
        }
        private void MostrarNodoEnPantalla(NodoCola unNodo)
        {
            if (unNodo != null)
            {
                LstCola.Items.Add(unNodo.Nombre);
                if(unNodo.Siguiente != null)
                {
                    MostrarNodoEnPantalla(unNodo.Siguiente);
                }
            }
        }

        private void btnDesencolar_Click(object sender, EventArgs e)
        {
            if (_cola.Vacia())
            {
                MessageBox.Show("La cola esta vacia");
            }
            else
            {
                NodoCola unNuevoNodo = new NodoCola();
                _cola .Desencolar(unNuevoNodo);
                MostrarCola();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if(LstCola.SelectedIndex > 0)
            {
                LstCola.Items[LstCola.SelectedIndex]=txtNombre.Text;
                _cola.Modificar(poc, txtNombre.Text);
                LstCola.Items[poc] = txtNombre.Text;
            }
            else
            {
                MessageBox.Show("Por favor, Selecciona un nombre para modificar");
            }
        }

        private void LstCola_SelectedIndexChanged(object sender, EventArgs e)
        {
            poc = LstCola.SelectedIndex;
        }
    }
}
