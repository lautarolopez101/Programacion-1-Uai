﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados.Teorias.Lista_Doblemente_Enlazada
{
    public class ListaDoble
    {
        public NodoDoblementeEnlazado Inicio;

        public void AgregarNodo(NodoDoblementeEnlazado unNodo)
        {
            if(Inicio == null)
            {
                Inicio = unNodo;
            }
            else
            {
                NodoDoblementeEnlazado aux = Inicio;
                Inicio = unNodo;
                Inicio.Siguiente = aux;
                aux.Anterior = Inicio;
               
            }
        }
        public NodoDoblementeEnlazado BuscarUltimo(NodoDoblementeEnlazado unNodo)
        {
           if(unNodo.Siguiente == null)
            {
                return unNodo;
            }
            else
            {
                return BuscarUltimo(unNodo.Siguiente);
            }
        }
        public void AgregarUltimo(NodoDoblementeEnlazado unNodo)
        {
            if(Inicio == null)
            {
                Inicio=unNodo;
            }
            else
            {
                NodoDoblementeEnlazado aux = BuscarUltimo(Inicio);
                aux.Siguiente = unNodo;
                unNodo.Anterior = aux;
            }
        }
        public NodoDoblementeEnlazado BuscarPos(int poc, NodoDoblementeEnlazado unNodo)
        {
            for(int i = 0;i<poc; i++)
            {
                unNodo = unNodo.Siguiente;
            }
            return unNodo;
        }
        public void AgregarDespues(int poc, NodoDoblementeEnlazado unNodo)
        {
            NodoDoblementeEnlazado aux = BuscarPos(poc,Inicio);
            NodoDoblementeEnlazado auxsiguiente = aux.Siguiente;
            NodoDoblementeEnlazado auxanterior = aux.Anterior;
            unNodo.Siguiente = auxsiguiente;
            unNodo.Anterior= auxanterior;
            aux.Siguiente = unNodo;
            unNodo.Anterior = aux;
           
        }

        public void Modificar(int poc, string nombre)
        {
            NodoDoblementeEnlazado aux = Inicio;
            for(int i = 0;i< poc && aux != null; i++)
            {
                aux = aux.Siguiente;
            }
            if(aux!= null)
            {
                aux.Nombre = nombre;
            }
        }

        public void EliminarPrincipio()
        {
            Inicio = Inicio.Siguiente;
            Inicio.Anterior = null;
        }

        public void EliminarSeleccionado(int poc)
        {
            if(poc == 0)
            {
                Inicio= Inicio.Siguiente;
                return;
            }
            NodoDoblementeEnlazado aux = BuscarPos(poc-1, Inicio);
            if(aux != null && aux.Siguiente != null)
            {
                NodoDoblementeEnlazado eliminado = aux.Siguiente;
                aux.Siguiente = eliminado.Siguiente;
                aux.Anterior = eliminado.Anterior;
            }
        }
    }
}
