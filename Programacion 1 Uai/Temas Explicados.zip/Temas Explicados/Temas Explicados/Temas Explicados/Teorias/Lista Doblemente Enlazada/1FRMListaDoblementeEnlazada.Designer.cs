﻿namespace Temas_Explicados.Teorias.Lista_Doblemente_Enlazada
{
    partial class ListaDoblementeEnlazada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAgregar = new System.Windows.Forms.Button();
            this.LSTNombres = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.btnEliminarPrincipio = new System.Windows.Forms.Button();
            this.btnAgregarDespues = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.btnEliminarSeleccionado = new System.Windows.Forms.Button();
            this.btnAgregarUltimo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(41, 105);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(100, 44);
            this.btnAgregar.TabIndex = 1;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // LSTNombres
            // 
            this.LSTNombres.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.LSTNombres.FormattingEnabled = true;
            this.LSTNombres.ItemHeight = 29;
            this.LSTNombres.Location = new System.Drawing.Point(234, 12);
            this.LSTNombres.Name = "LSTNombres";
            this.LSTNombres.Size = new System.Drawing.Size(304, 410);
            this.LSTNombres.TabIndex = 7;
            this.LSTNombres.SelectedIndexChanged += new System.EventHandler(this.LSTNombres_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nombre";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(41, 57);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 20);
            this.txtNombre.TabIndex = 0;
            // 
            // btnEliminarPrincipio
            // 
            this.btnEliminarPrincipio.Location = new System.Drawing.Point(41, 305);
            this.btnEliminarPrincipio.Name = "btnEliminarPrincipio";
            this.btnEliminarPrincipio.Size = new System.Drawing.Size(100, 44);
            this.btnEliminarPrincipio.TabIndex = 5;
            this.btnEliminarPrincipio.Text = "Eliminar";
            this.btnEliminarPrincipio.UseVisualStyleBackColor = true;
            this.btnEliminarPrincipio.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnAgregarDespues
            // 
            this.btnAgregarDespues.Location = new System.Drawing.Point(41, 205);
            this.btnAgregarDespues.Name = "btnAgregarDespues";
            this.btnAgregarDespues.Size = new System.Drawing.Size(100, 44);
            this.btnAgregarDespues.TabIndex = 3;
            this.btnAgregarDespues.Text = "Insertar";
            this.btnAgregarDespues.UseVisualStyleBackColor = true;
            this.btnAgregarDespues.Click += new System.EventHandler(this.btnAgregarDespues_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(41, 255);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(100, 44);
            this.btnActualizar.TabIndex = 4;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // btnEliminarSeleccionado
            // 
            this.btnEliminarSeleccionado.Location = new System.Drawing.Point(41, 355);
            this.btnEliminarSeleccionado.Name = "btnEliminarSeleccionado";
            this.btnEliminarSeleccionado.Size = new System.Drawing.Size(100, 44);
            this.btnEliminarSeleccionado.TabIndex = 6;
            this.btnEliminarSeleccionado.Text = "Eliminar Seleccionado";
            this.btnEliminarSeleccionado.UseVisualStyleBackColor = true;
            this.btnEliminarSeleccionado.Click += new System.EventHandler(this.btnEliminarSeleccionado_Click);
            // 
            // btnAgregarUltimo
            // 
            this.btnAgregarUltimo.Location = new System.Drawing.Point(41, 155);
            this.btnAgregarUltimo.Name = "btnAgregarUltimo";
            this.btnAgregarUltimo.Size = new System.Drawing.Size(100, 44);
            this.btnAgregarUltimo.TabIndex = 2;
            this.btnAgregarUltimo.Text = "Agregar Ultimo";
            this.btnAgregarUltimo.UseVisualStyleBackColor = true;
            this.btnAgregarUltimo.Click += new System.EventHandler(this.btnAgregarUltimo_Click);
            // 
            // ListaDoblementeEnlazada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.btnAgregarUltimo);
            this.Controls.Add(this.btnEliminarSeleccionado);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.btnAgregarDespues);
            this.Controls.Add(this.btnEliminarPrincipio);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LSTNombres);
            this.Controls.Add(this.btnAgregar);
            this.Name = "ListaDoblementeEnlazada";
            this.Text = "ListaDoblementeEnlazada";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.ListBox LSTNombres;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnEliminarPrincipio;
        private System.Windows.Forms.Button btnAgregarDespues;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnEliminarSeleccionado;
        private System.Windows.Forms.Button btnAgregarUltimo;
    }
}