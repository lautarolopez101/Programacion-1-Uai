﻿namespace Temas_Explicados
{
    partial class Lista_Simple_Enlazada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAgregar = new System.Windows.Forms.Button();
            this.LstEnlazada = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.btnEliminarSeleccionado = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnAgregarDespuesSeleccionado = new System.Windows.Forms.Button();
            this.btnAgregarUltimo = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(12, 115);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(197, 23);
            this.btnAgregar.TabIndex = 1;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // LstEnlazada
            // 
            this.LstEnlazada.BackColor = System.Drawing.Color.Red;
            this.LstEnlazada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LstEnlazada.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstEnlazada.ForeColor = System.Drawing.Color.White;
            this.LstEnlazada.FormattingEnabled = true;
            this.LstEnlazada.ItemHeight = 17;
            this.LstEnlazada.Location = new System.Drawing.Point(258, 57);
            this.LstEnlazada.Name = "LstEnlazada";
            this.LstEnlazada.Size = new System.Drawing.Size(182, 291);
            this.LstEnlazada.TabIndex = 6;
            this.LstEnlazada.SelectedIndexChanged += new System.EventHandler(this.LstEnlazada_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(12, 70);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(197, 20);
            this.txtNombre.TabIndex = 7;
            // 
            // btnEliminarSeleccionado
            // 
            this.btnEliminarSeleccionado.Location = new System.Drawing.Point(12, 260);
            this.btnEliminarSeleccionado.Name = "btnEliminarSeleccionado";
            this.btnEliminarSeleccionado.Size = new System.Drawing.Size(197, 23);
            this.btnEliminarSeleccionado.TabIndex = 6;
            this.btnEliminarSeleccionado.Text = "Eliminar Seleccionando";
            this.btnEliminarSeleccionado.UseVisualStyleBackColor = true;
            this.btnEliminarSeleccionado.Click += new System.EventHandler(this.btnEliminarSeleccionado_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(12, 202);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(197, 23);
            this.btnModificar.TabIndex = 4;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnAgregarDespuesSeleccionado
            // 
            this.btnAgregarDespuesSeleccionado.Location = new System.Drawing.Point(12, 144);
            this.btnAgregarDespuesSeleccionado.Name = "btnAgregarDespuesSeleccionado";
            this.btnAgregarDespuesSeleccionado.Size = new System.Drawing.Size(197, 23);
            this.btnAgregarDespuesSeleccionado.TabIndex = 2;
            this.btnAgregarDespuesSeleccionado.Text = "Agregar Despues del Seleccionado";
            this.btnAgregarDespuesSeleccionado.UseVisualStyleBackColor = true;
            this.btnAgregarDespuesSeleccionado.Click += new System.EventHandler(this.btnAgregarDespuesSeleccionado_Click);
            // 
            // btnAgregarUltimo
            // 
            this.btnAgregarUltimo.Location = new System.Drawing.Point(12, 173);
            this.btnAgregarUltimo.Name = "btnAgregarUltimo";
            this.btnAgregarUltimo.Size = new System.Drawing.Size(197, 23);
            this.btnAgregarUltimo.TabIndex = 3;
            this.btnAgregarUltimo.Text = "Agregar Ultimo";
            this.btnAgregarUltimo.UseVisualStyleBackColor = true;
            this.btnAgregarUltimo.Click += new System.EventHandler(this.btnAgregarUltimo_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(88, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(287, 29);
            this.label2.TabIndex = 8;
            this.label2.Text = "Lista Enlazada Simple";
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(12, 231);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(197, 23);
            this.btnEliminar.TabIndex = 5;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click_1);
            // 
            // Lista_Simple_Enlazada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(476, 361);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAgregarUltimo);
            this.Controls.Add(this.btnAgregarDespuesSeleccionado);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.btnEliminarSeleccionado);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LstEnlazada);
            this.Controls.Add(this.btnAgregar);
            this.Name = "Lista_Simple_Enlazada";
            this.Text = "Lista_Simple_Enlazada";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.ListBox LstEnlazada;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnEliminarSeleccionado;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnAgregarDespuesSeleccionado;
        private System.Windows.Forms.Button btnAgregarUltimo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnEliminar;
    }
}