﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados
{
    public partial class _5FRMBloc_de_Notas : Form
    {
        public _5FRMBloc_de_Notas()
        {
            InitializeComponent();
        }

        private string rutarchivo = "";

        private void cortarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(txtNotas.SelectedText.Length > 0)
            {
                Clipboard.SetText(txtNotas.SelectedText);
                txtNotas.SelectedText=string.Empty;
            }
            else
            {
                MessageBox.Show("No has seleccionado Nada");
            }
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(txtNotas.SelectedText.Length > 0)
            {
                Clipboard.SetText(txtNotas.SelectedText);
            }
            else
            {
                MessageBox.Show("No has seleccionado nada");
            }
        }

        private void pegarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                txtNotas.Paste();
            }
            else
            {
                MessageBox.Show("No hay nada en el Portapapeles");
            }
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
           txtNotas.SelectedText = string.Empty;
        }

        private void fechaYHoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtNotas.Text = DateTime.Now.ToString();
        }

        private void seleccionarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtNotas.SelectAll();
        }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(GuardarArchivos.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    File.WriteAllText(GuardarArchivos.FileName,txtNotas.Text);
                    MessageBox.Show("Archivo Guardado exitosamente.","Guardar",MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show($"Error al guardar el archivo", "Error",MessageBoxButtons.OK, MessageBoxIcon.Error);    
                }
            }
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(AbrirArchivos.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string abrir = File.ReadAllText(AbrirArchivos.FileName);
                   txtNotas.Text=abrir;
                    rutarchivo = AbrirArchivos.FileName;
                    MessageBox.Show("Archivo abierto correctamente.","Abierto",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show($"Error al abrir el archivo.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(rutarchivo))
            {
                try
                {
                    File.WriteAllText(rutarchivo, txtNotas.Text);
                    MessageBox.Show("Archivo guardado correctamente.", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show($"Error al guardar el archivo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (GuardarArchivos.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(GuardarArchivos.FileName, txtNotas.Text);
                        MessageBox.Show("Archivo Guardado exitosamente.", "Guardar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch
                    {
                        MessageBox.Show($"Error al guardar el archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void guardarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(rutarchivo))
            {
                try
                {
                    File.WriteAllText(rutarchivo, txtNotas.Text);
                    MessageBox.Show("Archivo guardado correctamente.", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show($"Error al guardar el archivo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (GuardarArchivos.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(GuardarArchivos.FileName, txtNotas.Text);
                        MessageBox.Show("Archivo Guardado exitosamente.", "Guardar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch
                    {
                        MessageBox.Show($"Error al guardar el archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void CerrarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                rutarchivo = "";
                txtNotas.Clear();
                MessageBox.Show("Archivo cerrado correctamente","Cerrado",MessageBoxButtons.OK,MessageBoxIcon.Hand);
            }
            catch
            {
                MessageBox.Show("El archivo no se pudo cerrar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImprimirDialog.Document = ImprimirDocumento;

            if(ImprimirDialog.ShowDialog() == DialogResult.OK)
            {
                ImprimirDocumento.Print();
            }
        }

        private void ImprimirDocumento_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font fuente = new Font("Arial",12);
            string textoAImprimir = txtNotas.Text;
            e.Graphics.DrawString(textoAImprimir,fuente,Brushes.Black,new Point(100,100));
        }
    }
}
