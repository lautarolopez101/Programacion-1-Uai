﻿namespace Temas_Explicados
{
    partial class FRMPaint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMPaint));
            this.HojaDeDibujo = new System.Windows.Forms.PictureBox();
            this.CintaDeMenu = new System.Windows.Forms.MenuStrip();
            this.archivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.guardarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guardarComoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cortarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pegarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CintaDeHerramientas = new System.Windows.Forms.ToolStrip();
            this.ColorRed = new System.Windows.Forms.ToolStripButton();
            this.ColorWhite = new System.Windows.Forms.ToolStripButton();
            this.ColorYellow = new System.Windows.Forms.ToolStripButton();
            this.ColorGreen = new System.Windows.Forms.ToolStripButton();
            this.ColorBlue = new System.Windows.Forms.ToolStripButton();
            this.ColorBlack = new System.Windows.Forms.ToolStripButton();
            this.ColorOrange = new System.Windows.Forms.ToolStripButton();
            this.ColorPink = new System.Windows.Forms.ToolStripButton();
            this.ColorGray = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.Borrador = new System.Windows.Forms.ToolStripButton();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.CambiarElGrosor = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.HojaDeDibujo)).BeginInit();
            this.CintaDeMenu.SuspendLayout();
            this.CintaDeHerramientas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CambiarElGrosor)).BeginInit();
            this.SuspendLayout();
            // 
            // HojaDeDibujo
            // 
            this.HojaDeDibujo.BackColor = System.Drawing.Color.White;
            this.HojaDeDibujo.Location = new System.Drawing.Point(0, 72);
            this.HojaDeDibujo.Name = "HojaDeDibujo";
            this.HojaDeDibujo.Size = new System.Drawing.Size(859, 466);
            this.HojaDeDibujo.TabIndex = 0;
            this.HojaDeDibujo.TabStop = false;
            this.HojaDeDibujo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.HojaDeDibujo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.HojaDeDibujo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // CintaDeMenu
            // 
            this.CintaDeMenu.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.CintaDeMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivosToolStripMenuItem,
            this.edtToolStripMenuItem});
            this.CintaDeMenu.Location = new System.Drawing.Point(0, 0);
            this.CintaDeMenu.Name = "CintaDeMenu";
            this.CintaDeMenu.Size = new System.Drawing.Size(859, 24);
            this.CintaDeMenu.TabIndex = 1;
            this.CintaDeMenu.Text = "menuStrip1";
            // 
            // archivosToolStripMenuItem
            // 
            this.archivosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirToolStripMenuItem,
            this.toolStripSeparator1,
            this.guardarToolStripMenuItem,
            this.guardarComoToolStripMenuItem,
            this.toolStripSeparator2,
            this.imprimirToolStripMenuItem,
            this.toolStripSeparator3,
            this.salirToolStripMenuItem});
            this.archivosToolStripMenuItem.Name = "archivosToolStripMenuItem";
            this.archivosToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.archivosToolStripMenuItem.Text = "Archivos";
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(223, 6);
            // 
            // guardarToolStripMenuItem
            // 
            this.guardarToolStripMenuItem.Name = "guardarToolStripMenuItem";
            this.guardarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.guardarToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.guardarToolStripMenuItem.Text = "Guardar";
            // 
            // guardarComoToolStripMenuItem
            // 
            this.guardarComoToolStripMenuItem.Name = "guardarComoToolStripMenuItem";
            this.guardarComoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.G)));
            this.guardarComoToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.guardarComoToolStripMenuItem.Text = "Guardar Como";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(223, 6);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(223, 6);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            // 
            // edtToolStripMenuItem
            // 
            this.edtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cortarToolStripMenuItem,
            this.copiarToolStripMenuItem,
            this.pegarToolStripMenuItem});
            this.edtToolStripMenuItem.Name = "edtToolStripMenuItem";
            this.edtToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.edtToolStripMenuItem.Text = "Editar";
            // 
            // cortarToolStripMenuItem
            // 
            this.cortarToolStripMenuItem.Name = "cortarToolStripMenuItem";
            this.cortarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cortarToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.cortarToolStripMenuItem.Text = "Cortar";
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.copiarToolStripMenuItem.Text = "Copiar";
            // 
            // pegarToolStripMenuItem
            // 
            this.pegarToolStripMenuItem.Name = "pegarToolStripMenuItem";
            this.pegarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pegarToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.pegarToolStripMenuItem.Text = "Pegar";
            // 
            // CintaDeHerramientas
            // 
            this.CintaDeHerramientas.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.CintaDeHerramientas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ColorRed,
            this.ColorWhite,
            this.ColorYellow,
            this.ColorGreen,
            this.ColorBlue,
            this.ColorBlack,
            this.ColorOrange,
            this.ColorPink,
            this.ColorGray,
            this.toolStripButton1,
            this.toolStripButton2,
            this.Borrador});
            this.CintaDeHerramientas.Location = new System.Drawing.Point(0, 24);
            this.CintaDeHerramientas.Name = "CintaDeHerramientas";
            this.CintaDeHerramientas.Size = new System.Drawing.Size(859, 45);
            this.CintaDeHerramientas.TabIndex = 2;
            this.CintaDeHerramientas.Text = "toolStrip1";
            // 
            // ColorRed
            // 
            this.ColorRed.BackColor = System.Drawing.Color.Red;
            this.ColorRed.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorRed.Image = ((System.Drawing.Image)(resources.GetObject("ColorRed.Image")));
            this.ColorRed.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorRed.Name = "ColorRed";
            this.ColorRed.Size = new System.Drawing.Size(23, 42);
            
            // 
            // ColorWhite
            // 
            this.ColorWhite.BackColor = System.Drawing.Color.White;
            this.ColorWhite.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorWhite.Image = ((System.Drawing.Image)(resources.GetObject("ColorWhite.Image")));
            this.ColorWhite.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorWhite.Name = "ColorWhite";
            this.ColorWhite.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorYellow
            // 
            this.ColorYellow.BackColor = System.Drawing.Color.Yellow;
            this.ColorYellow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorYellow.Image = ((System.Drawing.Image)(resources.GetObject("ColorYellow.Image")));
            this.ColorYellow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorYellow.Name = "ColorYellow";
            this.ColorYellow.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorGreen
            // 
            this.ColorGreen.BackColor = System.Drawing.Color.Green;
            this.ColorGreen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorGreen.Image = ((System.Drawing.Image)(resources.GetObject("ColorGreen.Image")));
            this.ColorGreen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorGreen.Name = "ColorGreen";
            this.ColorGreen.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorBlue
            // 
            this.ColorBlue.BackColor = System.Drawing.Color.Blue;
            this.ColorBlue.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorBlue.Image = ((System.Drawing.Image)(resources.GetObject("ColorBlue.Image")));
            this.ColorBlue.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorBlue.Name = "ColorBlue";
            this.ColorBlue.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorBlack
            // 
            this.ColorBlack.BackColor = System.Drawing.Color.Black;
            this.ColorBlack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorBlack.Image = ((System.Drawing.Image)(resources.GetObject("ColorBlack.Image")));
            this.ColorBlack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorBlack.Name = "ColorBlack";
            this.ColorBlack.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorOrange
            // 
            this.ColorOrange.BackColor = System.Drawing.Color.Orange;
            this.ColorOrange.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorOrange.Image = ((System.Drawing.Image)(resources.GetObject("ColorOrange.Image")));
            this.ColorOrange.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorOrange.Name = "ColorOrange";
            this.ColorOrange.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorPink
            // 
            this.ColorPink.BackColor = System.Drawing.Color.Pink;
            this.ColorPink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ColorPink.Image = ((System.Drawing.Image)(resources.GetObject("ColorPink.Image")));
            this.ColorPink.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorPink.Name = "ColorPink";
            this.ColorPink.Size = new System.Drawing.Size(23, 42);
            // 
            // ColorGray
            // 
            this.ColorGray.BackColor = System.Drawing.Color.Gray;
            this.ColorGray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.ColorGray.Image = ((System.Drawing.Image)(resources.GetObject("ColorGray.Image")));
            this.ColorGray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorGray.Name = "ColorGray";
            this.ColorGray.Size = new System.Drawing.Size(23, 42);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.BackColor = System.Drawing.Color.White;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Margin = new System.Windows.Forms.Padding(0);
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 25);
            this.toolStripButton1.Click += new System.EventHandler(this.CambiarColor_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(32, 42);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.lapiz_Click);
            // 
            // Borrador
            // 
            this.Borrador.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Borrador.Image = ((System.Drawing.Image)(resources.GetObject("Borrador.Image")));
            this.Borrador.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Borrador.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Borrador.Name = "Borrador";
            this.Borrador.Size = new System.Drawing.Size(39, 42);
            this.Borrador.Text = "toolStripButton3";
            this.Borrador.Click += new System.EventHandler(this.Borrador_Click);
            // 
            // CambiarElGrosor
            // 
            this.CambiarElGrosor.Location = new System.Drawing.Point(314, 37);
            this.CambiarElGrosor.Name = "CambiarElGrosor";
            this.CambiarElGrosor.Size = new System.Drawing.Size(120, 20);
            this.CambiarElGrosor.TabIndex = 3;
            this.CambiarElGrosor.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.CambiarElGrosor.ValueChanged += new System.EventHandler(this.CambiarElGrosor_ValueChanged);
            // 
            // FRMPaint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 540);
            this.Controls.Add(this.CambiarElGrosor);
            this.Controls.Add(this.CintaDeHerramientas);
            this.Controls.Add(this.HojaDeDibujo);
            this.Controls.Add(this.CintaDeMenu);
            this.MainMenuStrip = this.CintaDeMenu;
            this.Name = "FRMPaint";
            this.Text = "FRMPaint";
            ((System.ComponentModel.ISupportInitialize)(this.HojaDeDibujo)).EndInit();
            this.CintaDeMenu.ResumeLayout(false);
            this.CintaDeMenu.PerformLayout();
            this.CintaDeHerramientas.ResumeLayout(false);
            this.CintaDeHerramientas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CambiarElGrosor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox HojaDeDibujo;
        private System.Windows.Forms.MenuStrip CintaDeMenu;
        private System.Windows.Forms.ToolStripMenuItem archivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem guardarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guardarComoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cortarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pegarToolStripMenuItem;
        private System.Windows.Forms.ToolStrip CintaDeHerramientas;
        private System.Windows.Forms.ToolStripButton ColorRed;
        private System.Windows.Forms.ToolStripButton ColorWhite;
        private System.Windows.Forms.ToolStripButton ColorYellow;
        private System.Windows.Forms.ToolStripButton ColorGreen;
        private System.Windows.Forms.ToolStripButton ColorBlue;
        private System.Windows.Forms.ToolStripButton ColorBlack;
        private System.Windows.Forms.ToolStripButton ColorOrange;
        private System.Windows.Forms.ToolStripButton ColorPink;
        private System.Windows.Forms.ToolStripButton ColorGray;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton Borrador;
        private System.Windows.Forms.NumericUpDown CambiarElGrosor;
    }
}