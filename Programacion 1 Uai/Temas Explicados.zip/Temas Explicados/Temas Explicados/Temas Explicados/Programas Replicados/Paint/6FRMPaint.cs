﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados
{
    public partial class FRMPaint : Form
    {
        private bool isDrawing= false;
        private Point previousPoint;
        private int penWidth = 2;
        private Color currentColor = Color.Black;
        private bool isErasing = false;
        private Bitmap drawingBitmap;


        public FRMPaint()
        {
            InitializeComponent();
            drawingBitmap = new Bitmap(HojaDeDibujo.Width, HojaDeDibujo.Height);

            this.HojaDeDibujo.MouseDown += new MouseEventHandler(this.pictureBox1_MouseDown);
            this.HojaDeDibujo.MouseMove += new MouseEventHandler(this.pictureBox1_MouseMove);
            this.HojaDeDibujo.MouseUp += new MouseEventHandler(this.pictureBox1_MouseUp);

            this.ColorRed.Click += new EventHandler(this.CambiarColor_Click);

            //this.HojaDeDibujo.Paint += new PaintEventHandler(this.HojaDeDibujo_Paint);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isDrawing = true;
            previousPoint = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                using (Graphics g = HojaDeDibujo.CreateGraphics())
                {
                    Pen pen;
                    if (isErasing)
                    {
                        pen = new Pen(Color.White,penWidth);
                    }
                    else
                    {
                        pen = new Pen(currentColor,penWidth);
                    }
                    g.DrawLine(pen, previousPoint,e.Location);
                    previousPoint = e.Location;
                }
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDrawing= false;
        }

        private void CambiarColor_Click(object sender, EventArgs e)
        {
            ColorDialog colordialog = new ColorDialog();
            if(colordialog.ShowDialog() == DialogResult.OK)
            {
                currentColor = colordialog.Color;
            }
        }
        
        private void lapiz_Click(object sender, EventArgs e)        //Boton para activar el lapiz
        {
            isErasing = false;
        }

        private void Borrador_Click(object sender, EventArgs e)     //Boton para activar el borrador
        {
            isErasing = true;
            
        }


        private void CambiarElGrosor_ValueChanged(object sender, EventArgs e)
        {
            penWidth = (int)CambiarElGrosor.Value;
        }
    }
}
