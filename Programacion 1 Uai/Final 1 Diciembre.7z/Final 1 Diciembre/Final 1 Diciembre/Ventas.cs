﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_1_Diciembre
{
    public partial class Ventas : Form
    {

        /*
         Tema 1: Combina datos de dos archivos CSV 
        (clientes.csv y ventas.csv) utilizando un campo común (ClienteID)           LISTO
        y escribe el resultado en un nuevo archivo.
         */

        /*
         Tema 2: Actualizar valores en un archivo CSV según una condición
            Actualiza los precios de los productos en el archivo                    FALTA HACER
            productos.csv si el ProductoID coincide con un valor dado y 	
            guarda los resultados en un archivo nuevo

         */


        public Ventas()
        {
            InitializeComponent();
        }

        private void Ventas_Load(object sender, EventArgs e)
        {
            CargaDatos();
        }

        private void CargaDatos()
        {
            FileStream fsventas = new FileStream("Ventas.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fsventas);
            string linea;
            string[] vVentas = new string[0];
            linea = sr.ReadLine();

            while (linea != null)
            {
                vVentas = linea.Split(';');
                dataGridView1.Rows.Add(vVentas);
                linea = sr.ReadLine();
            }
            fsventas.Close();
            sr.Close();
        }

        private void btnAgregarVenta_Click(object sender, EventArgs e)
        {
            string codigoventas = txtCodigoVenta.Text;
            string codigocliente= txtCodigoCliente.Text;
            string monto = txtMonto.Text;

            if (string.IsNullOrEmpty(codigocliente) || string.IsNullOrEmpty(codigoventas) || string.IsNullOrEmpty(monto))
            {
                MessageBox.Show("Por favor completa todos los campos");
                return;
            }

            string nuevalinea = $"{codigoventas};{codigocliente};{monto}";


            using (StreamWriter swventas = new StreamWriter("Ventas.csv", true))
            {
                swventas.WriteLine(nuevalinea);
            }
            dataGridView1.Rows.Add(codigoventas,codigocliente,monto);

            txtCodigoVenta.Clear();
            txtCodigoCliente.Clear();
            txtMonto.Clear();
            txtCodigoVenta.Focus();
        }
    }
}
