﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_1_Diciembre
{
    public partial class Clientes : Form
    {
        public Clientes()
        {
            InitializeComponent();
        }
        private void Clientes_Load(object sender, EventArgs e)
        {
            CargaDatos();
        }

        private void CargaDatos()
        {
            FileStream fsclientes = new FileStream("Clientes.csv",FileMode.Open,FileAccess.Read);
            StreamReader sr = new StreamReader(fsclientes);
            string linea;
            string[] vcliente = new string[0];
            linea = sr.ReadLine();

            while (linea != null)
            {
                vcliente = linea.Split(';');
                dataGridView1.Rows.Add(vcliente);
                linea = sr.ReadLine();
            }
            fsclientes.Close();
            sr.Close();
        }


        private void btnAgregarCliente_Click(object sender, EventArgs e)
        {
            string codigocliente = txtCodigo.Text;
            string apellido = txtApellido.Text;
            string nombre = txtNombre.Text;

            if (string.IsNullOrEmpty(codigocliente) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("Por favor completa todos los campos");
                return;
            }

            string nuevalinea = $"{codigocliente};{apellido};{nombre}";


            using (StreamWriter swcliente = new StreamWriter("Clientes.csv", true))
            {
                swcliente.WriteLine(nuevalinea);
            }
            dataGridView1.Rows.Add(codigocliente, apellido, nombre);

            txtApellido.Clear();
            txtNombre.Clear();
            txtCodigo.Clear();
            txtCodigo.Focus();

        }

       
    }
}
