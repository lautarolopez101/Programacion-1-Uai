﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Final_1_Diciembre
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            CargaDatos();
        }

        private void CargaDatos()
        {
            DGVCliente.Rows.Clear();
            DGVVentas.Rows.Clear();
          
           FileStream fsClientes = new FileStream("Clientes.csv",FileMode.Open,FileAccess.Read);
           FileStream fsVentas = new FileStream("Ventas.csv", FileMode.Open,FileAccess.Read);

            StreamReader srclientes = new StreamReader(fsClientes);
            StreamReader srventas = new StreamReader(fsVentas);

            string lineaclientes = "";
            string lineaventas = "";

            string[] vectorclientes = new string[0];
            string[] vectorventas = new string[0];

            lineaclientes = srclientes.ReadLine();
            lineaventas = srventas.ReadLine();  

            while(lineaclientes != null)
            {
                vectorclientes = lineaclientes.Split(';');
                DGVCliente.Rows.Add(vectorclientes);
                lineaclientes = srclientes.ReadLine();
            }

            while(lineaventas != null)
            {
                vectorventas = lineaventas.Split(';');
                DGVVentas.Rows.Add(vectorventas);
                lineaventas = srventas.ReadLine();
            }

            fsClientes.Close();
            fsVentas.Close();
            srventas.Close();
            srclientes.Close();

        }

       

        private void btnNuevoArchivo_Click(object sender, EventArgs e)
        {
            txt.Clear();
            FileStream fsClientes = new FileStream("Clientes.csv", FileMode.Open, FileAccess.Read);

            StreamReader srclientes = new StreamReader(fsClientes);

            string lineaclientes = "";

            string[] vectorclientes = new string[0];

            lineaclientes = srclientes.ReadLine();

           while (lineaclientes != null)
            {
                vectorclientes = lineaclientes.Split(';');
                txt.Text += "Nombre " + "\t" + "Apellido"  + "\t"+"Codigo de Venta" +"\t" +"Monto"+Environment.NewLine;
                txt.Text += vectorclientes[2]  + "\t" + vectorclientes[1] +"\t";
                ventas(vectorclientes[0]);
                lineaclientes = srclientes.ReadLine();
            }

            fsClientes.Close();
            srclientes.Close();


          

        }

        private void ventas(string id)
        {
            FileStream fsVentas = new FileStream("Ventas.csv", FileMode.Open, FileAccess.Read);
            StreamReader srventas = new StreamReader(fsVentas);
            string[] vectorventas = new string[0];
            string lineaventas = "";
            lineaventas = srventas.ReadLine();

            while (lineaventas != null)
            {
                vectorventas = lineaventas.Split(';');
                if (vectorventas[1] == id)
                {
                    txt.Text += vectorventas[0] + "\t" + "\t" + vectorventas[2] + Environment.NewLine;
                    txt.Text += "==================================================" + Environment.NewLine;

                }
                lineaventas = srventas.ReadLine();
            }


            fsVentas.Close();
            srventas.Close();

            CargaDatos();
        }

        private void btnCrearArchivo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt.Text))
            {
                MessageBox.Show("El cuadro de texto esta vacio");
                return;
            }
                if(guardar.ShowDialog()  == DialogResult.OK)
                {
                    using (FileStream fs = new FileStream(guardar.FileName, FileMode.Create, FileAccess.Write))
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        sw.Write(txt.Text);
                    }
                    MessageBox.Show("Contenido guardado exitosamente");
                }
            
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Clientes clientes = new Clientes();
                clientes.Show();
            }
            catch
            {
                MessageBox.Show($"Error","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Ventas ventas = new Ventas();
                ventas.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
