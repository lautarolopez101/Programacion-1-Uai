﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.VisualStyles;

namespace Temas_Explicados.Teorias.Manejo_de_Varios_Archivos
{
    public partial class Comercios : Form
    {
        public Comercios()
        {
            InitializeComponent();
        }
        private List<string[]> datos = new List<string[]>();

        private void CargarDatos()
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Comercios.csv")){
                using(StreamReader sr = new StreamReader("Comercios.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }
        private void Comercios_Load(object sender, EventArgs e)
        {
            CargarDatos();
        }


        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string comercioid = txtIDComercio.Text;
            string nombrecomercio = txtNombreComercio.Text;

            if(string.IsNullOrEmpty(comercioid)||
                string.IsNullOrEmpty(nombrecomercio))
            {
                MessageBox.Show("Por favor, Completar todos los campos de texto.");
                return;
            }

            AgregarDatos(comercioid, nombrecomercio);
            txtIDComercio.Clear();
            txtNombreComercio.Clear();
            txtIDComercio.Focus();
            MessageBox.Show("Datos Guardados Correctamente.");
        }
        private void AgregarDatos(string id, string nombre)
        {
            string[] nuevodato = {id, nombre};
            datos.Add(nuevodato);
            dataGridView1.Rows.Add(nuevodato);
            GuardarDatos();
        }

        private void GuardarDatos()
        {
            datos = datos.OrderBy(d => d[0]).ThenBy(d => d[1]).ToList();
            using (StreamWriter sw = new StreamWriter("Comercios.csv"))
            {
                foreach (var vector in datos)
                {
                    sw.WriteLine(string.Join(";", vector));
                }
            }
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Comercios.csv"))
            {
                using (StreamReader sr = new StreamReader("Comercios.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }
    }
}
