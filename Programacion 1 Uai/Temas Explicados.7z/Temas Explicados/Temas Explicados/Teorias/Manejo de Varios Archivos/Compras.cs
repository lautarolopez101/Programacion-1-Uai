﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Temas_Explicados.Teorias.Manejo_de_Varios_Archivos
{
    public partial class Compras : Form
    {
        public Compras()
        {
            InitializeComponent();
        }
        private List<string[]> datos = new List<string[]>();

        private void Cargadatos()
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Compras.csv"))
            {
                using (StreamReader sr = new StreamReader("Compras.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }

        }
        private void Compras_Load(object sender, EventArgs e)
        {
            Cargadatos();
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string dni = txtDNI.Text;
            string idProducto = txtIDProducto.Text;
            string idComercio= txtIDComercio.Text;

            if (string.IsNullOrEmpty(dni) ||
                string.IsNullOrEmpty(idProducto) ||
                string.IsNullOrEmpty(idComercio))
            {
                MessageBox.Show("Por favor, completa todos los campos");
                return;
            }
            AgregarDatos(dni, idProducto, idComercio);
            txtDNI.Clear();
            txtIDComercio.Clear();
            txtIDProducto.Clear();
            txtDNI.Focus();
            MessageBox.Show("Datos guardados Correctamente.");
        }
        private void AgregarDatos(string dni, string idproducto, string idcomercio)
        {
            string[] nuevodato = { dni, idproducto,idcomercio};
            datos.Add(nuevodato);
            dataGridView1.Rows.Add(nuevodato);
            GuardarDatos();
        }
        private void GuardarDatos()
        {
            datos = datos.OrderBy(d => d[0]).ThenBy(d => d[1]).ToList();
            using (StreamWriter sw = new StreamWriter("Clientes.csv"))
            {
                foreach (var vector in datos)
                {
                    sw.WriteLine(string.Join(";", vector));
                }
            }
        }
        private void btnCargar_Click(object sender, EventArgs e)
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Compras.csv"))
            {
                using (StreamReader sr = new StreamReader("Compras.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }

        
    }
}
