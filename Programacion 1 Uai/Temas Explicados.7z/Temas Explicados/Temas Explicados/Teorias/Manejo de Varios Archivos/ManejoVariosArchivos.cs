﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados.Teorias.Manejo_de_Varios_Archivos
{
    public partial class ManejoVariosArchivos : Form
    {
        public ManejoVariosArchivos()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cargadatos();
        }
        private void cargadatos()
        {
            FileStream fsClientes = new FileStream("Clientes.csv", FileMode.Open, FileAccess.Read);
            FileStream fsProductos = new FileStream("Productos.csv", FileMode.Open, FileAccess.Read);
            FileStream fsCompras = new FileStream("Compras.csv", FileMode.Open, FileAccess.Read);
            FileStream fsComercios = new FileStream("Comercios.csv", FileMode.Open, FileAccess.Read);

            StreamReader srClientes = new StreamReader(fsClientes);
            StreamReader srProductos = new StreamReader(fsProductos);
            StreamReader srCompras = new StreamReader(fsCompras);
            StreamReader srComercios = new StreamReader(fsComercios);

            string lineaClientes = "";
            string lineaProductos = "";
            string lineaCompras = "";
            string lineaComercios = "";

            string[] vClientes = new string[0];
            string[] vProductos = new string[0];
            string[] vCompras = new string[0];
            string[] vComercios = new string[0];

            lineaClientes = srClientes.ReadLine();
            lineaProductos = srProductos.ReadLine();
            lineaCompras = srCompras.ReadLine();
            lineaComercios = srComercios.ReadLine();

            while (lineaClientes != null)
            {
                vClientes = lineaClientes.Split(';');
                dataGridView1.Rows.Add(vClientes);
                lineaClientes = srClientes.ReadLine();
            }
            while (lineaProductos != null)
            {
                vProductos = lineaProductos.Split(';');
                dataGridView2.Rows.Add(vProductos);
                lineaProductos = srProductos.ReadLine();
            }
            while (lineaCompras != null)
            {
                vCompras = lineaCompras.Split(';');
                dataGridView3.Rows.Add(vCompras);
                lineaCompras = srCompras.ReadLine();
            }
            while (lineaComercios != null)
            {
                vComercios = lineaComercios.Split(';');
                dataGridView4.Rows.Add(vComercios);
                lineaComercios = srComercios.ReadLine();
            }

            srClientes.Close();
            srComercios.Close();
            srProductos.Close();
            srCompras.Close();
            fsClientes.Close();
            fsProductos.Close();
            fsCompras.Close();
            fsComercios.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            txt.Text += "Reporte" + Environment.NewLine;

            FileStream fsClientes = new FileStream("Clientes.csv", FileMode.Open, FileAccess.Read);
            StreamReader srClientes = new StreamReader(fsClientes);

            string lineaClientes = "";
            string[] vClientes = new string[0];

            lineaClientes = srClientes.ReadLine();
            while (lineaClientes != null)
            {
                txt.Text += "///////////////////////////////////////" + Environment.NewLine;
                txt.Text += "Apellido" + "\t" + "Nombre" + "\t" + "Forma de Pago" + Environment.NewLine;
                vClientes = lineaClientes.Split(';');
                txt.Text += vClientes[1] + "\t" + vClientes[2] + "\t" + vClientes[3] + Environment.NewLine;
                txt.Text += "///////////////////////////////////////" + Environment.NewLine;
                txt.Text += "Comercio" + "\t" + "Producto" + "\t" + "Precio" + Environment.NewLine;
                txt.Text += "------------------------------------" + Environment.NewLine;
                dni_compra(Convert.ToInt32(vClientes[0]));
                lineaClientes = srClientes.ReadLine();

            }
            fsClientes.Close();
            srClientes.Close();
        }

        private void dni_compra(int v)
        {
            FileStream fsCompras = new FileStream("Compras.csv", FileMode.Open, FileAccess.Read);
            StreamReader srCompras = new StreamReader(fsCompras);
            string lineaComercio = "";
            string[] vCompras = new string[0];
            lineaComercio = srCompras.ReadLine();

            while (lineaComercio != null)
            {
                vCompras = lineaComercio.Split(';');
               
                if (Convert.ToInt32(vCompras[0]) == v)
                {
                    comercio(Convert.ToInt32(vCompras[2]));
                    produ(Convert.ToInt32(vCompras[1]));
                }
                lineaComercio = srCompras.ReadLine();
            }
            fsCompras.Close();
            srCompras.Close();
        }

        private void comercio(int v)
        {
            FileStream fsComercio = new FileStream("Comercios.csv", FileMode.Open, FileAccess.Read);
            StreamReader srComercio = new StreamReader(fsComercio);
            string lineacomercio = "";
            string[] vComercio = new string[0];
            lineacomercio = srComercio.ReadLine();
            while (lineacomercio != null)
            {
                vComercio = lineacomercio.Split(';');
                if (Convert.ToInt32(vComercio[0]) == v)
                {
                    txt.Text += vComercio[1];
                }
                lineacomercio = srComercio.ReadLine();

            }
            fsComercio.Close();
            srComercio.Close();
        }


        private void produ(int v)
        {
            FileStream fsProducto = new FileStream("Productos.csv", FileMode.Open, FileAccess.Read);
            StreamReader srProducto = new StreamReader(fsProducto);
            string lineaproducto = "";
            string[] vProducto = new string[0];
            lineaproducto = srProducto.ReadLine();
            while (lineaproducto != null)
            {
                vProducto = lineaproducto.Split(';');
                if (Convert.ToInt32(vProducto[0]) == v)
                {
                    txt.Text += " " + vProducto[1] + " " + vProducto[2] + Environment.NewLine;
                    txt.Text += Environment.NewLine;
                }

                lineaproducto = srProducto.ReadLine();
            }
            fsProducto.Close();
            srProducto.Close();
        }

        private void agregarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Clientes clientes = new Clientes();
                clientes.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void agregarComerciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Comercios comercios = new Comercios();
                comercios.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comprasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Compras compras = new Compras();
                compras.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Productos productos = new Productos();
                productos.Show();
            }
            catch
            {
                MessageBox.Show($"Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
