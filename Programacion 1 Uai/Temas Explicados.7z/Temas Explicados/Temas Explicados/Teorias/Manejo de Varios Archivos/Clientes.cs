﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Temas_Explicados.Teorias.Manejo_de_Varios_Archivos
{
    public partial class Clientes : Form
    {
        public Clientes()
        {
            InitializeComponent();
        }
        private List<string[]> datos = new List<string[]>();
        private void Clientes_Load(object sender, EventArgs e)
        {
            CargaDatos();
        }
        private void CargaDatos()
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Clientes.csv"))
            {
                using(StreamReader sr = new StreamReader("Clientes.csv"))
                {
                    string linea;
                    while((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string dni = txtDNI.Text;
            string apellido = txtApellido.Text;
            string nombre = txtNombre.Text;
            string metodo = txtMetododepago.Text;

            if(string.IsNullOrEmpty(dni) ||
                string.IsNullOrEmpty(apellido)||
                string.IsNullOrEmpty(nombre) ||
                string.IsNullOrEmpty(metodo))
            {
                MessageBox.Show("Por favor, completa todos los campos");
                return;
            }
            AgregarDatos(dni, apellido, nombre, metodo);
            txtApellido.Clear();
            txtNombre.Clear();
            txtMetododepago.Clear();
            txtDNI.Clear();
            txtDNI.Focus();
            MessageBox.Show("Datos guardados Correctamente.");

        }
        private void AgregarDatos(string dni, string apellido, string nombre, string metododepago)
        {
            string[] nuevodato = { dni, apellido, nombre, metododepago };
            datos.Add(nuevodato);
            dataGridView1.Rows.Add(nuevodato);
            GuardarDatos();
        }
        private void GuardarDatos()
        {
            datos = datos.OrderBy(d => d[0]).ThenBy(d => d[1]).ToList();
            using (StreamWriter sw = new StreamWriter("Clientes.csv"))
            {
                foreach(var vector in datos)
                {
                    sw.WriteLine(string.Join(";", vector));
                }
            }
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            datos.Clear();
            dataGridView1.Rows.Clear();

            if (File.Exists("Clientes.csv"))
            {
                using (StreamReader sr = new StreamReader("Clientes.csv"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] vector = linea.Split(';');
                        datos.Add(vector);
                        dataGridView1.Rows.Add(vector);
                    }
                }
            }
        }

       
    }
}
