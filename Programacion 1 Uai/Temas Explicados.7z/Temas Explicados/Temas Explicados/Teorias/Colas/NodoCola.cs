﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class NodoCola
    {
        public string Nombre { get; set; }
        public NodoCola Siguiente { get; set; }
    }
}
