﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class Cola
    {
        public NodoCola Inicio;
        public void Encolar(NodoCola unNodo)
        {
            if (Inicio == null)
            {
                Inicio = unNodo;
            }
            else
            {
                NodoCola aux = BuscarUltimo(Inicio);
                aux.Siguiente = unNodo;
            }
        }

        public NodoCola BuscarUltimo(NodoCola unNodo)
        {
            if (unNodo.Siguiente == null)
            {
                return unNodo;
            }
            else
            {
                return BuscarUltimo(unNodo.Siguiente);
            }
        }

        public void Modificar(int index, string nuevonombre)
        {
            NodoCola aux = Inicio;
            for (int i = 0; i < index && aux != null; i++)
            {
                aux = aux.Siguiente;
            }
            if (aux != null)
            {
                aux.Nombre = nuevonombre;
            }
        }


        public void Desencolar(NodoCola unNodo)
        {
            Inicio = Inicio.Siguiente;
        }

        public bool Vacia()
        {
            return (Inicio == null);
        }
    }
}
