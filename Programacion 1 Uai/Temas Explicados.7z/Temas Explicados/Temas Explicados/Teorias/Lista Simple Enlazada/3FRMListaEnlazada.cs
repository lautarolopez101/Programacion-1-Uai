﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Temas_Explicados
{

    public partial class Lista_Simple_Enlazada : Form
    {
       private int poc;

        Lista_Enlazada _lista = new Lista_Enlazada();
        public Lista_Simple_Enlazada()
        {
            InitializeComponent();
        }

        public void AgregarItemaALista(NodoListaSimple unNodo)
        {
            if( unNodo != null)
            {
                LstEnlazada.Items.Add(unNodo.Nombre);
                AgregarItemaALista(unNodo.Siguiente);
            }
        }
        public void MostrarLista()
        {
            LstEnlazada.Items.Clear();

            if (_lista.Inicio != null)
            {
                AgregarItemaALista(_lista.Inicio);   
            }
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text.Length > 0)
            {
                NodoListaSimple unNuevoNodo = new NodoListaSimple(txtNombre.Text);
                unNuevoNodo.Nombre = txtNombre.Text;
                _lista.AgregarPrincipio(unNuevoNodo);
                txtNombre.Clear();
                txtNombre.Focus();
                MostrarLista();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (LstEnlazada.SelectedIndex >= 0)
            {
                poc = LstEnlazada.SelectedIndex;
                _lista.Modificar(poc, txtNombre.Text);
                LstEnlazada.Items[poc]= txtNombre.Text;
                
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un Nombre para poder modificar");
            }
            
        }

       

        private void btnAgregarUltimo_Click(object sender, EventArgs e)
        {
            if(txtNombre.Text.Length > 0)
            {
                NodoListaSimple unNuevoNodo = new NodoListaSimple(txtNombre.Text);
                unNuevoNodo.Nombre = txtNombre.Text;
                _lista.AgregarUltimo(unNuevoNodo);
                txtNombre.Clear();
                txtNombre.Focus();
                MostrarLista();
            }
        }

        private void btnAgregarDespuesSeleccionado_Click(object sender, EventArgs e)
        {
            NodoListaSimple unNuevoNodo = new NodoListaSimple(txtNombre.Text);
            unNuevoNodo.Nombre = txtNombre.Text;
            _lista.AgregarDespues(poc,unNuevoNodo);
            MostrarLista();
        }

        private void LstEnlazada_SelectedIndexChanged(object sender, EventArgs e)
        {
            poc = LstEnlazada.SelectedIndex;
            if (LstEnlazada.SelectedItem != null)
            {
                txtNombre.Text = LstEnlazada.SelectedItem.ToString();
            }

        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            _lista.EliminarPrincipio();
            MostrarLista();
        }

        private void btnEliminarSeleccionado_Click(object sender, EventArgs e)
        {
            
            _lista.EliminarSeleccionado(poc);
            LstEnlazada.Items.RemoveAt(poc);
            MostrarLista();
        }
    }
}
