﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class NodoListaSimple
    {
        public string Nombre { get; set; }
        public NodoListaSimple Siguiente{ get; set; }
        public NodoListaSimple(string nombre)
        {
            this.Nombre = nombre;
            this.Siguiente = null;
        }
    }
}
