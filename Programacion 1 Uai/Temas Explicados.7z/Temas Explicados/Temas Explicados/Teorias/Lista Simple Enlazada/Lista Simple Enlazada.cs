﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class Lista_Enlazada
    {
        public NodoListaSimple Inicio;

        public void AgregarPrincipio(NodoListaSimple unNodo)
        {
            if (Inicio == null)
            {
                Inicio = unNodo;
            }
            else
            {
                NodoListaSimple aux = Inicio;
                Inicio = unNodo;
                Inicio.Siguiente = aux;
            }
        }

        public void AgregarUltimo(NodoListaSimple unNodo)
        {
            if(Inicio == null)
            {
                Inicio=unNodo;
            }
            else
            {
                NodoListaSimple aux = BuscarUltimo(Inicio);
                aux.Siguiente = unNodo;
            }
        }

        public NodoListaSimple BuscarUltimo(NodoListaSimple unNodo) 
        {
            if(unNodo.Siguiente == null)
            {
                return unNodo;
            }
            else
            {
                return BuscarUltimo(unNodo.Siguiente);
            }
        }

      public void Modificar(int index,string nuevonombre)
        {
            NodoListaSimple aux = Inicio;
            for(int i = 0;i < index && aux != null; i++)
            {
                aux = aux.Siguiente;
            }
            if(aux != null)
            {
                aux.Nombre = nuevonombre;
            }
        }

        public void AgregarDespues(int poc, NodoListaSimple unNodo)
        {
           NodoListaSimple aux = BuscarPos(poc,Inicio);
           NodoListaSimple auxsiguiente = aux.Siguiente;
            unNodo.Siguiente = auxsiguiente;
            aux.Siguiente = unNodo;
            
        }
        public void EliminarSeleccionado(int poc)
        {
            if (poc == 0)
            {
                Inicio= Inicio.Siguiente;
                return;
            }
            NodoListaSimple aux = BuscarPos(poc-1, Inicio);
            if (aux != null && aux.Siguiente != null)
            {
                NodoListaSimple eliminado = aux.Siguiente;
                aux.Siguiente = eliminado.Siguiente;
            }
        }
        
        public NodoListaSimple BuscarPos(int poc, NodoListaSimple unNodo)
        {
            for(int i = 0;i<poc;i++)
            {
                unNodo = unNodo.Siguiente;
            }
            return unNodo;
        }

        public void EliminarPrincipio()
        {
            Inicio = Inicio.Siguiente;
        }
    }
}
