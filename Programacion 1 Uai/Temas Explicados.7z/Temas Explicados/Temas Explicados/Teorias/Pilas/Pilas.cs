﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class Pilas
    {

        public NodoPila _tope;


        public NodoPila Tope()
        {
            return _tope;
        }

        public void Apilar(NodoPila unNodo)
        {
            if (_tope == null)
            {
                _tope = unNodo;
            }
            else
            {
                NodoPila aux = _tope;
                _tope = unNodo;
                _tope.Siguiente = aux;
            }
        }

        public void Desapilar()
        {
            if (_tope != null)
            {
                _tope = _tope.Siguiente;
            }
        }

        public void Modificar(int poc, string nombre)
        {
            NodoPila aux = _tope;
            for(int i = 0;i<poc &&  aux != null;i++)
            {
                aux = aux.Siguiente;
            }
            if(aux != null)
            {
                aux.Nombre = nombre; 
            }
        }
    }
}
