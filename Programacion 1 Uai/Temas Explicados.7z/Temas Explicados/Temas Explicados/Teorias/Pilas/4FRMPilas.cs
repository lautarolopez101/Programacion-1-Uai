﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados
{
    public partial class FRMPilas : Form
    {
        private int poc;
        Pilas _pila = new Pilas();
        public FRMPilas()
        {
            InitializeComponent();
        }

        private void btnApilar_Click(object sender, EventArgs e)
        {
            NodoPila unNuevoNodo = new NodoPila();
            unNuevoNodo.Nombre = txtNombre.Text;
            _pila.Apilar(unNuevoNodo);
            txtNombre.Clear();
            txtNombre.Focus();
            MostrarPila();
        }

        private void btnDesapilar_Click(object sender, EventArgs e)
        {
            _pila.Desapilar();
            LstPila.Items.RemoveAt(0);
        }


        public void MostrarPila()
        {
            LstPila.Items.Clear();
            if(_pila.Tope()!=null)
            {
                MostrarNodoEnLista(_pila.Tope());
            }
        }

        public void MostrarNodoEnLista(NodoPila unNuevoNodo)
        {
            LstPila.Items.Add(unNuevoNodo.Nombre);
            if(unNuevoNodo.Siguiente != null)
            {
                MostrarNodoEnLista(unNuevoNodo.Siguiente);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if(LstPila.SelectedIndex >= 0)
            {
                poc = LstPila.SelectedIndex;
                _pila.Modificar(poc,txtNombre.Text);
                LstPila.Items[poc] = txtNombre.Text;
                MostrarPila();

            }
        }

        private void LstPila_SelectedIndexChanged(object sender, EventArgs e)
        {
            poc = LstPila.SelectedIndex;
            if(LstPila.SelectedItem != null)
            {
                txtNombre.Text=LstPila.SelectedItem.ToString(); 
            }
        }
    }
}
