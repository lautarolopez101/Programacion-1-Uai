﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados.Teorias.Lista_Doblemente_Enlazada
{
    public partial class ListaDoblementeEnlazada : Form
    {
        ListaDoble _lista = new ListaDoble();
        public ListaDoblementeEnlazada()
        {
            InitializeComponent();
        }
        private int poc;
        public void AgregarItemALista(NodoDoblementeEnlazado unNodo)
        {
            if(unNodo != null)
            {
                LSTNombres.Items.Add(unNodo.Nombre);
                AgregarItemALista(unNodo.Siguiente);
            }
        }

        public void Mostrar()
        {
            LSTNombres.Items.Clear();

            if(_lista.Inicio != null)
            {
                AgregarItemALista(_lista.Inicio);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            NodoDoblementeEnlazado unNuevoNodo = new NodoDoblementeEnlazado(txtNombre.Text);
            _lista.AgregarNodo(unNuevoNodo);
            unNuevoNodo.Nombre = txtNombre.Text;
            Mostrar();
            txtNombre.Clear();
            txtNombre.Focus();

        }

        private void btnAgregarDespues_Click(object sender, EventArgs e)
        {
            NodoDoblementeEnlazado unNuevoNodo = new NodoDoblementeEnlazado(txtNombre.Text);
            unNuevoNodo.Nombre = txtNombre.Text;
            _lista.AgregarDespues(poc,unNuevoNodo);
            Mostrar();

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
          if(LSTNombres.SelectedIndex >= 0)
            {
                poc = LSTNombres.SelectedIndex;
                _lista.Modificar(poc, txtNombre.Text);
                LSTNombres.Items[poc] = txtNombre.Text;
            }
            else
            {
                MessageBox.Show("Por Favor, Selecciona un Nombre para poder Modificar");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            _lista.EliminarPrincipio();
            Mostrar();
        }

        private void btnEliminarSeleccionado_Click(object sender, EventArgs e)
        {
            _lista.EliminarSeleccionado(poc);
            Mostrar();
        }

        private void btnAgregarUltimo_Click(object sender, EventArgs e)
        {
            NodoDoblementeEnlazado unNuevoNodo = new NodoDoblementeEnlazado(txtNombre.Text);
            _lista.AgregarUltimo(unNuevoNodo);
            unNuevoNodo.Nombre = txtNombre.Text;
            Mostrar();
            txtNombre.Clear();
            txtNombre.Focus();
        }

        private void LSTNombres_SelectedIndexChanged(object sender, EventArgs e)
        {
            poc = LSTNombres.SelectedIndex;
            if (LSTNombres.SelectedItem != null)
            {


                txtNombre.Text = LSTNombres.SelectedItem.ToString();
            }
        }
    }
}
