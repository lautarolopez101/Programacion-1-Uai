﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados.Teorias.Lista_Doblemente_Enlazada
{
    public class NodoDoblementeEnlazado
    {
        public string Nombre { get; set; }
        public NodoDoblementeEnlazado Siguiente { get; set; }
        public NodoDoblementeEnlazado Anterior { get; set; }
        public NodoDoblementeEnlazado(string nombre)
        {
            this.Nombre = nombre;
            this.Siguiente = null;
            this.Anterior = null;
        }
    }
}
