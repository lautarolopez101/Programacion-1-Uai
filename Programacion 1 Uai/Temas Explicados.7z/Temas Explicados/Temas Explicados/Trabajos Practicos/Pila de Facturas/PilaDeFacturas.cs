﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados.Trabajos_Practicos.Pila_de_Facturas
{
    public class PilaDeFacturas
    {
        //RECORDAR LO QUE EXPLICAMOS EN PILAS
        //SINO IR DE VUELTA A TEORIAS/PILAS/PILAS.CS
        //Y LEERLO NUEVAMENTE PARA REFRESCAR LA MEMORIA
        public NodoPilaDeFacturas Inicio;

        public void Apilar(NodoPilaDeFacturas unNodo)
        {
            if(Inicio == null)
            {
                Inicio = unNodo;
            }
            else
            {
                NodoPilaDeFacturas aux = Inicio;
                Inicio = unNodo;
                Inicio.Siguiente = aux;
            }
        }

        public void Desapilar()
        {
            Inicio = Inicio.Siguiente;
        }

        public void BuscarCliente(int poc,int numerocliente)
        {

        }



        //RECORDAR LO QUE EXPLICAMOS EN PILAS
        //SINO IR DE VUELTA A TEORIAS/PILAS/PILAS.CS
        //Y LEERLO NUEVAMENTE PARA REFRESCAR LA MEMORIA


    }
}
