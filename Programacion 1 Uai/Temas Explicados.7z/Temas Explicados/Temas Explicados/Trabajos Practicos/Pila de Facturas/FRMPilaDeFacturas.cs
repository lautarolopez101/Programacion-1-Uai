﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados.Trabajos_Practicos.Pila_de_Facturas
{
    public partial class FRMPilaDeFacturas : Form
    {
        private int poc;
        PilaDeFacturas _pila = new PilaDeFacturas();
        private bool encontrado = false;
        public FRMPilaDeFacturas()
        {
            InitializeComponent();
        }

        private void btnApilar_Click(object sender, EventArgs e)
        {
            if(txtNumeroDeFactura.Text.Length > 0)
            {
                //Creamos un NODO que solo sirve para este boton
                NodoPilaDeFacturas unNuevoNodo = new NodoPilaDeFacturas(Convert.ToInt32(txtNumeroDeFactura.Text), Convert.ToInt32(txtNumeroDeCliente.Text), Convert.ToInt32(txtImporte.Text), Convert.ToDateTime(DTPFecha.Text));
                //Le decimos que parte del nodo es cada textbox.text (el texto que esta dentro del textbox)
                unNuevoNodo.NumeroDeFactura= Convert.ToInt32(txtNumeroDeFactura.Text);
                unNuevoNodo.NumeroDeCliente = Convert.ToInt32(txtNumeroDeCliente.Text);
                unNuevoNodo.Importe = Convert.ToInt32(txtImporte.Text);
                unNuevoNodo.Fecha = Convert.ToDateTime(DTPFecha.Text);
                //Creamos un Entero que se llama "rowindex" y lo que tenga adentro va a ser la primera fila
                int rowindex = DGVFacturas.Rows.Add();
                // Y aca le decimos que en la FILA "rowindex"(Primera) y en la COLUMNA[x] el valor va a ser lo que
                // esta adentro del textbox correspondiente
                DGVFacturas.Rows[rowindex].Cells[0].Value = txtNumeroDeFactura.Text;
                DGVFacturas.Rows[rowindex].Cells[1].Value = txtNumeroDeCliente.Text;
                DGVFacturas.Rows[rowindex].Cells[2].Value = txtImporte.Text;
                DGVFacturas.Rows[rowindex].Cells[3].Value = DTPFecha.Text;
                //Llamamos a la funcion Apilar para que apile el nombre con su respectivo nodo
                _pila.Apilar(unNuevoNodo);
                

                //Limpiamos cada uno de los textbox para poder seguir agregando/modificar/buscar
                txtNumeroDeFactura.Clear();
                txtNumeroDeCliente.Clear();
                txtImporte.Clear();
                DTPFecha.ResetText();

                //Indicamos que cuando termine el proceso de apilar un NODO nos seleccione/enfoque el textbox primero (Numero de Factura)
                txtNumeroDeFactura.Focus();
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            poc = Convert.ToInt32(txtNumeroDeCliente.Text);

            foreach ( DataGridViewRow fila in DGVFacturas.Rows)
            {
                if (fila.Cells[1].Value != null && fila.Cells[1].Value.ToString() == Convert.ToString(poc))
                {
                    fila.Selected = true;
                    DGVFacturas.CurrentCell = fila.Cells[1];
                    encontrado = true;
                    break;

                }
            }
            if (!encontrado)
            {
                MessageBox.Show("Numero de Cliente no encontrado","Buscando....",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                btnEliminarSeleccionado.Enabled = true;
                btnModificar.Enabled = true;
            }
        }

        private void btnDesapilar_Click(object sender, EventArgs e)
        {
            //Indicamos que en el DGVFacturas(datagridview) y en la fila elimine (0) en este caso
            //como en la pila tenemos solamente acceso para agregar o eliminar desde el tope 
            //en este caso tenemos que desapilar siempre el primero
            DGVFacturas.Rows.RemoveAt(0);

            //pero tambien no falta poder desapilarlo desde la pila
            //sin esta funcion _pila.Desapilar(); solamente seria "VISUAL"
            _pila.Desapilar();
        }

        private void DGVFacturas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Le damos el valor de la fila seleccionamos sea un entero y que el entero nos indique en 
            //que fila esta posicionada
            poc = DGVFacturas.CurrentRow.Index;
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if(DGVFacturas.SelectedRows.Count > 0)
            {
               // DGVFacturas filaseleccionada = dg
            }

        }

        private void btnEliminarSeleccionado_Click(object sender, EventArgs e)
        {

        }
    }
}
