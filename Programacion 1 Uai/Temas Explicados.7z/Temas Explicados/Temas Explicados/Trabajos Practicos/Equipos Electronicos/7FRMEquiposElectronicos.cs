﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Temas_Explicados
{
    public partial class EquiposElectronicos : Form
    {

        ListaEnlazadaEquiposElectronicos _lista = new ListaEnlazadaEquiposElectronicos();
        int poc;
        
        public EquiposElectronicos()
        {
            InitializeComponent();
        }

        private void btnEliminarPrincipio_Click(object sender, EventArgs e)
        {
            ListaDatos.Rows.RemoveAt(0);
            _lista.EliminarPrincipio();

        }


        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if(txtCodigo.Text.Length > 0)
            {
                NodosEquiposElectronicos unNuevoNodo = new NodosEquiposElectronicos(Convert.ToInt32(txtCodigo.Text),txtDescripcion.Text,Convert.ToInt32(txtPrecio.Text),txtEstado.Text);
                unNuevoNodo.Codigo = Convert.ToInt32(txtCodigo.Text);
                unNuevoNodo.Descripcion = txtDescripcion.Text;
                unNuevoNodo.Estado = txtEstado.Text;
                unNuevoNodo.Precio = Convert.ToInt32(txtPrecio.Text);
                int rowIndex = ListaDatos.Rows.Add();
                ListaDatos.Rows[rowIndex].Cells[0].Value = txtCodigo.Text;
                ListaDatos.Rows[rowIndex].Cells[1].Value = txtDescripcion.Text;
                ListaDatos.Rows[rowIndex].Cells[2].Value = Convert.ToInt32(txtPrecio.Text);
                ListaDatos.Rows[rowIndex].Cells[3].Value = txtEstado.Text;
                _lista.Agregar(unNuevoNodo);
                txtCodigo.Clear();
                txtDescripcion.Clear();
                txtPrecio.Clear();
                txtEstado.Clear();
                txtCodigo.Focus();
            }
        }

        private void btnEliminarSeleccionado_Click(object sender, EventArgs e)
        {

            if(poc >= 0 && poc < _lista.cuento())
            {
                _lista.EliminarSeleccionado(poc);
                ListaDatos.Rows.RemoveAt(poc);
            }
        }

        private void ListaDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            poc = ListaDatos.CurrentRow.Index;

            txtCodigo.Text = ListaDatos[0, poc].Value.ToString();
            txtDescripcion.Text=ListaDatos[1, poc].Value.ToString();
            txtPrecio.Text = ListaDatos[2, poc].Value.ToString();
            txtEstado.Text = ListaDatos[3, poc].Value.ToString();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if(poc >=0 && poc < _lista.cuento())
            {
                ListaDatos[0,poc].Value = txtCodigo.Text;
                ListaDatos[1,poc].Value = txtDescripcion.Text;
                ListaDatos[2,poc].Value = txtPrecio.Text;
                ListaDatos[3,poc].Value = txtEstado.Text;


               NodosEquiposElectronicos unNuevoNodo = _lista.ObtenerNodo(poc);

                unNuevoNodo.Codigo = Convert.ToInt32(txtCodigo.Text);
                unNuevoNodo.Descripcion = txtDescripcion.Text;
                unNuevoNodo.Estado = txtEstado.Text;
                unNuevoNodo.Precio = Convert.ToInt32(txtPrecio.Text);
            }
        }

        private void AgregarDespues(NodosEquiposElectronicos unNuevoNodo)
        {
            if(poc>=0 && poc< ListaDatos.Rows.Count)
            {
                _lista.AgregarDespues(unNuevoNodo, poc);
                ListaDatos.Rows.Insert(poc + 1, unNuevoNodo.Codigo, unNuevoNodo.Descripcion, unNuevoNodo.Estado, unNuevoNodo.Precio);
            }
        }
        private void btnInsertar_Click(object sender, EventArgs e)
        {
           NodosEquiposElectronicos unNuevoNodo = new NodosEquiposElectronicos(Convert.ToInt32(txtCodigo.Text), txtDescripcion.Text, Convert.ToInt32(txtPrecio.Text), txtEstado.Text);
           AgregarDespues(unNuevoNodo);

            txtCodigo.Clear();
            txtDescripcion.Clear();
            txtEstado.Clear();
            txtPrecio.Clear();
            txtCodigo.Focus();
        }
    }
}
