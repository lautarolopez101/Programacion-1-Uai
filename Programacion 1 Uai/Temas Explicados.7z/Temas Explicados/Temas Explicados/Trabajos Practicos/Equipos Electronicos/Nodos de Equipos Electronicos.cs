﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class NodosEquiposElectronicos
    {
        public double Codigo { get; set; }
        public string Descripcion { get; set; }
        public float Precio { get; set; }
        public string Estado { get; set; }
        public NodosEquiposElectronicos Siguiente { get; set; }
        public NodosEquiposElectronicos Anterior { get; set; }

        public NodosEquiposElectronicos(double codigo,string descripcion,float precio,string estado)
        {
            this.Codigo = codigo;
            this.Descripcion = descripcion;
            this.Precio = precio;
            this.Estado = estado;
            this.Siguiente = null;
            this.Anterior = null;
        }
    }
}
