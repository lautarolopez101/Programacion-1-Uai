﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temas_Explicados
{
    public class ListaEnlazadaEquiposElectronicos
    {
        public NodosEquiposElectronicos Inicio;

        public void Agregar(NodosEquiposElectronicos unNodo)
        {
            if(Inicio == null)
            {
                Inicio = unNodo;
            }
            else
            {
                NodosEquiposElectronicos aux = Inicio;
                Inicio = unNodo;
                Inicio.Siguiente = aux;
            }
        }

        public void EliminarPrincipio()
        {
            Inicio = Inicio.Siguiente;
        }

      
        public NodosEquiposElectronicos ObtenerNodo(int poc)
        {
            NodosEquiposElectronicos aux= Inicio;
            int contador = 0;
            while(aux!= null && contador < poc)
            {
                aux = aux.Siguiente;
                contador++;
            }
            return aux;
        }
        public void AgregarDespues(NodosEquiposElectronicos unNuevoNodo, int poc)
        {
            NodosEquiposElectronicos aux = Inicio;
            int contador =0;
            while (aux!= null && contador < poc)
            {
                aux = aux.Siguiente;
                contador++;
            }
            if (aux!= null)
            {
                unNuevoNodo.Siguiente = aux.Siguiente;
                unNuevoNodo.Anterior = aux;
                if(aux.Siguiente != null)
                {
                    aux.Siguiente.Anterior = unNuevoNodo;
                }
                aux.Siguiente = unNuevoNodo;
            }
        }

        public void EliminarSeleccionado(int poc)
        {
            NodosEquiposElectronicos aux = Inicio;
            for(int i = 0; i< poc && aux!= null; i++)
            {
                aux = aux.Siguiente;
            }
            if(aux != null)
            {
                aux= aux.Siguiente;
            }
        }

        public int cuento()
        {
            int contador =0;
            NodosEquiposElectronicos aux =Inicio;
            while (aux != null)
            {
                contador++;
                aux = aux.Siguiente;
            }
            return contador;
        }
    }
}
