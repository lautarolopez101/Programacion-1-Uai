﻿namespace Temas_Explicados
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.practicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaEnlazadaSimpleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pilasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaDoblementeEnlazadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programasReplicadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blocDeNotasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabajoPracticoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaEnlazadaDeEqToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pilaDeFacturasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colaDeSolicitudesDeEmpleoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manejoDeArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manejoDeVariosArchivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.practicasToolStripMenuItem,
            this.programasReplicadosToolStripMenuItem,
            this.trabajoPracticoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(608, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // practicasToolStripMenuItem
            // 
            this.practicasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listaEnlazadaSimpleToolStripMenuItem1,
            this.pilasToolStripMenuItem,
            this.colasToolStripMenuItem,
            this.listaDoblementeEnlazadaToolStripMenuItem,
            this.manejoDeArchivoToolStripMenuItem,
            this.manejoDeVariosArchivosToolStripMenuItem});
            this.practicasToolStripMenuItem.Name = "practicasToolStripMenuItem";
            this.practicasToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.practicasToolStripMenuItem.Text = "Teorias";
            // 
            // listaEnlazadaSimpleToolStripMenuItem1
            // 
            this.listaEnlazadaSimpleToolStripMenuItem1.Name = "listaEnlazadaSimpleToolStripMenuItem1";
            this.listaEnlazadaSimpleToolStripMenuItem1.Size = new System.Drawing.Size(215, 22);
            this.listaEnlazadaSimpleToolStripMenuItem1.Text = "Lista Enlazada Simple";
            this.listaEnlazadaSimpleToolStripMenuItem1.Click += new System.EventHandler(this.listaEnlazadaSimpleToolStripMenuItem1_Click);
            // 
            // pilasToolStripMenuItem
            // 
            this.pilasToolStripMenuItem.Name = "pilasToolStripMenuItem";
            this.pilasToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.pilasToolStripMenuItem.Text = "Pilas";
            this.pilasToolStripMenuItem.Click += new System.EventHandler(this.pilasToolStripMenuItem_Click);
            // 
            // colasToolStripMenuItem
            // 
            this.colasToolStripMenuItem.Name = "colasToolStripMenuItem";
            this.colasToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.colasToolStripMenuItem.Text = "Colas";
            this.colasToolStripMenuItem.Click += new System.EventHandler(this.colasToolStripMenuItem_Click);
            // 
            // listaDoblementeEnlazadaToolStripMenuItem
            // 
            this.listaDoblementeEnlazadaToolStripMenuItem.Name = "listaDoblementeEnlazadaToolStripMenuItem";
            this.listaDoblementeEnlazadaToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.listaDoblementeEnlazadaToolStripMenuItem.Text = "Lista Doblemente Enlazada";
            this.listaDoblementeEnlazadaToolStripMenuItem.Click += new System.EventHandler(this.listaDoblementeEnlazadaToolStripMenuItem_Click);
            // 
            // programasReplicadosToolStripMenuItem
            // 
            this.programasReplicadosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blocDeNotasToolStripMenuItem,
            this.paintToolStripMenuItem});
            this.programasReplicadosToolStripMenuItem.Name = "programasReplicadosToolStripMenuItem";
            this.programasReplicadosToolStripMenuItem.Size = new System.Drawing.Size(136, 20);
            this.programasReplicadosToolStripMenuItem.Text = "Programas Replicados";
            // 
            // blocDeNotasToolStripMenuItem
            // 
            this.blocDeNotasToolStripMenuItem.Name = "blocDeNotasToolStripMenuItem";
            this.blocDeNotasToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.blocDeNotasToolStripMenuItem.Text = "Bloc de Notas";
            this.blocDeNotasToolStripMenuItem.Click += new System.EventHandler(this.blocDeNotasToolStripMenuItem_Click);
            // 
            // paintToolStripMenuItem
            // 
            this.paintToolStripMenuItem.Name = "paintToolStripMenuItem";
            this.paintToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.paintToolStripMenuItem.Text = "Paint";
            this.paintToolStripMenuItem.Click += new System.EventHandler(this.paintToolStripMenuItem_Click);
            // 
            // trabajoPracticoToolStripMenuItem
            // 
            this.trabajoPracticoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listaEnlazadaDeEqToolStripMenuItem,
            this.pilaDeFacturasToolStripMenuItem,
            this.colaDeSolicitudesDeEmpleoToolStripMenuItem});
            this.trabajoPracticoToolStripMenuItem.Name = "trabajoPracticoToolStripMenuItem";
            this.trabajoPracticoToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.trabajoPracticoToolStripMenuItem.Text = "Trabajo Practico";
            // 
            // listaEnlazadaDeEqToolStripMenuItem
            // 
            this.listaEnlazadaDeEqToolStripMenuItem.Name = "listaEnlazadaDeEqToolStripMenuItem";
            this.listaEnlazadaDeEqToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.listaEnlazadaDeEqToolStripMenuItem.Text = "Lista Enlazada de Equipos Electronicos";
            this.listaEnlazadaDeEqToolStripMenuItem.Click += new System.EventHandler(this.listaEnlazadaDeEqToolStripMenuItem_Click);
            // 
            // pilaDeFacturasToolStripMenuItem
            // 
            this.pilaDeFacturasToolStripMenuItem.Name = "pilaDeFacturasToolStripMenuItem";
            this.pilaDeFacturasToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.pilaDeFacturasToolStripMenuItem.Text = "Pila de Facturas";
            this.pilaDeFacturasToolStripMenuItem.Click += new System.EventHandler(this.pilaDeFacturasToolStripMenuItem_Click);
            // 
            // colaDeSolicitudesDeEmpleoToolStripMenuItem
            // 
            this.colaDeSolicitudesDeEmpleoToolStripMenuItem.Name = "colaDeSolicitudesDeEmpleoToolStripMenuItem";
            this.colaDeSolicitudesDeEmpleoToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.colaDeSolicitudesDeEmpleoToolStripMenuItem.Text = "Cola de Solicitudes de Empleo";
            this.colaDeSolicitudesDeEmpleoToolStripMenuItem.Click += new System.EventHandler(this.colaDeSolicitudesDeEmpleoToolStripMenuItem_Click);
            // 
            // manejoDeArchivoToolStripMenuItem
            // 
            this.manejoDeArchivoToolStripMenuItem.Name = "manejoDeArchivoToolStripMenuItem";
            this.manejoDeArchivoToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.manejoDeArchivoToolStripMenuItem.Text = "Manejo de Archivo";
            this.manejoDeArchivoToolStripMenuItem.Click += new System.EventHandler(this.manejoDeArchivoToolStripMenuItem_Click);
            // 
            // manejoDeVariosArchivosToolStripMenuItem
            // 
            this.manejoDeVariosArchivosToolStripMenuItem.Name = "manejoDeVariosArchivosToolStripMenuItem";
            this.manejoDeVariosArchivosToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.manejoDeVariosArchivosToolStripMenuItem.Text = "Manejo de Varios Archivos";
            this.manejoDeVariosArchivosToolStripMenuItem.Click += new System.EventHandler(this.manejoDeVariosArchivosToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(608, 442);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem practicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaEnlazadaSimpleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pilasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programasReplicadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blocDeNotasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paintToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabajoPracticoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaEnlazadaDeEqToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pilaDeFacturasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colaDeSolicitudesDeEmpleoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaDoblementeEnlazadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manejoDeArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manejoDeVariosArchivosToolStripMenuItem;
    }
}

